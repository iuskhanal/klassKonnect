import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://192.168.1.104'; // backend FastAPI URL

  // ---------- USER SIGNUP ----------
  static Future<bool> registerUser(String email, String password, String role) async {
    final response = await http.post(
      Uri.parse('$baseUrl/signup'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
        'role': role,
      }),
    );

    if (response.statusCode == 200) {
      print('Signup success: ${response.body}');
      return true;
    } else {
      print('Signup failed: ${response.body}');
      return false;
    }
  }

  // ---------- USER LOGIN ----------
  static Future<bool> loginUser(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      print('Login success: ${response.body}');
      return true;
    } else {
      print('Login failed: ${response.body}');
      return false;
    }
  }

  // ---------- FETCH RESOURCES ----------
  static Future<List<dynamic>> getResources() async {
    final response = await http.get(Uri.parse('$baseUrl/resources'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load resources');
    }
  }
}
