import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'home_screen.dart';
import 'detail_screen.dart'; // Import your ResourceDetailScreen file

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KlassKonnect',
      theme: ThemeData(primarySwatch: Colors.blue),

      // Start from the login screen
      home: const LoginScreen(),

      // Define all named routes
      routes: {
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(role: 'Learner'),
        '/details': (context) => const ResourceDetailScreen(
              resource: {'title': 'Sample Resource', 'type': 'PDF'},
            ), // ✅ fixed — added required parameter
      },
    );
  }
}
